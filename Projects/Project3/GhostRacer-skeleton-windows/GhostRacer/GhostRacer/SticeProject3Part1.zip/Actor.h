#ifndef ACTOR_H_
#define ACTOR_H_
#include "GraphObject.h"
class StudentWorld;
class GhostRacer;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, int startDirection, double size, bool isCAW, int depth, StudentWorld* SW, int vspeed, int hspeed)
		:GraphObject(imageID, startX, startY, startDirection, size, depth)
	{
		m_isCAW = isCAW;
		m_direction = startDirection;
		m_depth = depth;
		m_SW = SW;
		m_vertSpeed = vspeed;
		m_horSpeed = hspeed;
	};
	virtual void doSomething() = 0;
	bool isCAW();
	virtual bool isAlive();
	double getVSpeed();
	double getHSpeed();
	void setDead();
	void setVSpeed(int s);
	void setHSpeed(int s);
	StudentWorld* getWorld();
	virtual ~Actor(){};
private:
	bool m_isCAW;
	double m_direction;
	int m_depth;
	StudentWorld* m_SW = nullptr;
	bool m_isAlive = true;
	double m_vertSpeed;
	double m_horSpeed;
};

class BorderLine : public Actor
{
public:
	BorderLine(int imageID, int startX, int startY, int startDirection, double size, int depth, StudentWorld* SW, int vspeed, int hspeed, bool isCAW = false)
		:Actor(imageID, startX
			, startY, startDirection, size, isCAW, depth, SW, vspeed, hspeed) {
	};
	virtual void doSomething();
	virtual ~BorderLine() {};
private:
};

class GhostRacer : public Actor
{
public:
	GhostRacer(int ImageID, int StartX, int StartY, int StartDirection, double Size, int vSpeed,int hspeed, StudentWorld* SW, int Depth, int Health, bool IsCAW, int HW)
		:Actor(ImageID, StartX, StartY, StartDirection, Size, IsCAW, Depth, SW, vSpeed, hspeed) 
	{
		m_health = Health;
		m_holyWaterLeft = HW;
	}
	virtual void doSomething();
	void move();
	virtual ~GhostRacer() {};
private:
	int m_health;
	int m_holyWaterLeft;
};


#endif // ACTOR_H_
