#include "Actor.h"
#include "StudentWorld.h"
using namespace std;
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

bool Actor::isCAW()
{
 return m_isCAW;
}

StudentWorld* Actor:: getWorld()
{
	return m_SW;
};

bool Actor::isAlive() { return m_isAlive; };
double Actor::getVSpeed() { return m_vertSpeed; };
double Actor::getHSpeed() { return m_horSpeed; };
void Actor::setVSpeed(int s) { m_vertSpeed+=s; };
void Actor::setHSpeed(int s) { m_horSpeed += s; };
void Actor::setDead() { m_isAlive = false; };



void GhostRacer::doSomething()
{
	int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
	int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
	int ch;
	if (getX() <= LEFT_EDGE)
	{
		//Need to damage GR
		setDirection(82);
		getWorld()->playSound(SOUND_VEHICLE_CRASH);
	}
	if (getX() >= RIGHT_EDGE)
	{
		//Need to damage GR
		setDirection(98);
		getWorld()->playSound(SOUND_VEHICLE_CRASH);
	}
	if (getWorld()->getKey(ch))
	{
		switch (ch)
		{
		case(KEY_PRESS_LEFT):
		{
			if (getDirection() < 114)
			{
				setDirection(getDirection() + 8);
			}
			break;
		}
		case(KEY_PRESS_RIGHT):
		{
			if (getDirection() > 66)
			{
				setDirection(getDirection() - 8);
			}
			break;
		}
		case(KEY_PRESS_UP):
		{
			if (getVSpeed() < 5)
				setVSpeed(1);
			break;
		}
		case(KEY_PRESS_DOWN):
		{
			if (getVSpeed() > -1)
				setVSpeed(-1);
			break;
		}
		}
	}
	move();
}

void GhostRacer::move()
{
	double max_shift_per_tick = 4.0;
	double delta_x = (cos(getDirection() * (3.141592653/180)) * max_shift_per_tick);
	moveTo((getX() + delta_x), getY());
}








void BorderLine::doSomething()
{
	double vert_speed = getVSpeed() - (getWorld()->getGRSpeed());
	double newY = getY() + vert_speed;
	double newX = getX() + getHSpeed();
	moveTo(newX, newY);
	if (getX() < 0 || getY() < 0 || getX() > VIEW_WIDTH || getY() > VIEW_HEIGHT)
	{
		setDead();
	}
	return;
}
