#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include "Actor.h"
using namespace std;


GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    actorList.size();
    gr = nullptr;
}
double StudentWorld::getGRSpeed() { return gr->getVSpeed(); };



int StudentWorld::init()
{
    actorList.size();
    gr = new GhostRacer(IID_GHOST_RACER, 128, 32, 90, 4.0, 0, 0, this, 0, 100, true, 10);
    int N = VIEW_HEIGHT / SPRITE_HEIGHT;
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
    for (int i = 0; i < N; i++)
    {
        Actor* a = new BorderLine(IID_YELLOW_BORDER_LINE, LEFT_EDGE, i * SPRITE_HEIGHT, 0, 2.0, 1, this, -4, 0);
        actorList.push_back(a);
    }
    for (int i = 0; i < N; i++)
    {
        Actor* a = new BorderLine(IID_YELLOW_BORDER_LINE, RIGHT_EDGE, i * SPRITE_HEIGHT, 0, 2.0, 1,this, -4, 0);
        actorList.push_back(a);
    }
    int M = VIEW_HEIGHT / (4 * SPRITE_HEIGHT);
    for (int i = 0; i < M; i++)
    {
        Actor* a = new BorderLine(IID_WHITE_BORDER_LINE, LEFT_EDGE + ROAD_WIDTH/3, i * (4*SPRITE_HEIGHT), 0, 2.0,1, this, -4, 0, false);
        actorList.push_back(a);
        if (i == (M - 1))
        {
            ycLastWBorderline = (i * static_cast<double>((4 * SPRITE_HEIGHT)));
        }
    }
    for (int i = 0; i < M; i++)
    {
        Actor* a = new BorderLine(IID_WHITE_BORDER_LINE, RIGHT_EDGE - ROAD_WIDTH / 3, i * (4 * SPRITE_HEIGHT), 0, 2.0, 1,this, -4, 0, false);
        actorList.push_back(a);
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    gr->doSomething();
    for (int i = 0; i < actorList.size(); i++)
    {
        actorList[i]->doSomething();
    }
    //Delete borderlines that are off of the screen
    for (int i = 0; i < actorList.size(); i++)
    {
        bool maybeAlive = actorList[i]->isAlive();
        if (!maybeAlive)
        {
            delete actorList[i];
            actorList.erase(actorList.begin() + i);
        }
    }
    //Add new borderlines
    double new_border_y = static_cast<double>(VIEW_HEIGHT - SPRITE_HEIGHT);
    ycLastWBorderline = (ycLastWBorderline - 4 - (gr->getVSpeed()));
    double delta_y = new_border_y - (ycLastWBorderline);
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
    if (delta_y >= SPRITE_HEIGHT)
    {
        Actor* a = new BorderLine(IID_YELLOW_BORDER_LINE, RIGHT_EDGE,new_border_y, 0, 2.0, 2, this, -4, 0);
        actorList.push_back(a);
        Actor* b = new BorderLine(IID_YELLOW_BORDER_LINE, LEFT_EDGE, new_border_y, 0, 2.0, 2, this, -4, 0);
        actorList.push_back(b);
    }
    if (delta_y >= static_cast<double>((4 * SPRITE_HEIGHT)))
    {
        Actor* c = new BorderLine(IID_WHITE_BORDER_LINE, (ROAD_CENTER - (ROAD_WIDTH / 2) + (ROAD_WIDTH / 3)), new_border_y, 0, 2.0, 2, this, -4, 0, false);
        actorList.push_back(c);
        Actor* d = new BorderLine(IID_WHITE_BORDER_LINE, (ROAD_CENTER + (ROAD_WIDTH / 2) - (ROAD_WIDTH / 3)), new_border_y, 0, 2.0, 2, this, -4, 0, false);
        actorList.push_back(d);
        ycLastWBorderline = new_border_y;
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete gr;
    for (int i = 0; i < actorList.size(); i++)
    {
        delete actorList[i];
    }
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}
