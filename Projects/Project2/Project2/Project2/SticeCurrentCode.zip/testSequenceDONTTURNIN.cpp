
//#include <stdlib.h>
//#include <crtdbg.h>
#include "Sequence.h"
#include <iostream>
#include <cassert>

using namespace std;

int main()
{
	Sequence ss;  // ItemType is std::string
	ss.insert(1, "a");
	//ss.insert(0, "a");	
	/*
	for (int i = 0; i < ss.size(); i++)
	{
		r.get(i, x);
		cout << x << endl;
	}
	*/
	//_CrtDumpMemoryLeaks();
}

