
//Class declarations

class Investment
{
public:
    Investment(string name, int price) 
    { m_name = name; m_price = price;};
    string name() const { return m_name; };
    virtual bool fungible() const { return false; };
    virtual string description() const  = 0;
    int purchasePrice() const { return m_price; };
    virtual ~Investment() {};
private:
    string m_name;
    int m_price;
};

class Stock : public Investment
{
public:
    Stock(string name, int cost, string ticker) : Investment(name, cost) { m_ticker = ticker; };
    string description() const { return ("stock trading as " + m_ticker); };
    virtual bool fungible() const { return true; };
    virtual ~Stock() {cout << "Destroying " + this->name() + ", a stock holding" + "\n"; };
private:
    string m_ticker;
};

class Painting : public Investment
{
public:
    Painting(string name, int cost) : Investment(name, cost) {};
    string description() const { return "painting"; };
    virtual ~Painting() { cout << "Destroying " + this->name() + ", a painting" + "\n"; };
};

class House : public Investment
{
public:
    House(string address, int cost) : Investment(address, cost) {};
    string description() const { return "house"; };
    virtual ~House() { cout << "Destroying the house " + this->name() + "\n"; };
};
