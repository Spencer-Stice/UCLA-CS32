
#include "Sequence.h"
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
    Sequence s;
    Sequence s2;

       
    cout << "Passed all tests" << endl;
}
